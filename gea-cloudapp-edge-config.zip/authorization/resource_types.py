PLATFORM="platform"
DEVICE="device"